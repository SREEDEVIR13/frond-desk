import './logo.css';
// import logo from '../../images/suyati-logo.png';
import VisitorForm from '../VisitorForm';
function Logo() {
  return (
    <div className="logo">
    <div className="logo-handler">
      <img src="/Image/suyati-logo.png" alt="Logo."/>      </div>
      <VisitorForm />   </div>
  );
   
 
   
}

export default Logo;
